import 'package:flutter/material.dart';
import 'halaman_login.dart';

void main() {
  runApp(const MyApp());
}

// Custom Color Palette
class AppColors {
  static const Color primary = Color(0xFFF26627);
  static const Color secondary = Color(0xFFF9A26C);
  static const Color background = Color(0xFFEFEEEE);
  static const Color accent = Color(0xFF9BD7D1);
  static const Color dark = Color(0xFF325D79);
  static const Color green = Color(0xFF2D6A4F);
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'UTS FLUTTER DIAN PUSPITASARI (23670171)',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: AppColors.primary,
        scaffoldBackgroundColor: AppColors.background,
        useMaterial3: true,
      ),
      home: const HalamanLogin(),
    );
  }
}